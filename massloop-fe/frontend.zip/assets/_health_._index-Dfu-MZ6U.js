import{r as e}from"./rolldown-runtime-QTnfLwEv.js";import{N as t,j as n,r}from"./chunk-5KNZJZUH-03iYwFZK.js";import{D as i,S as a,a as o,d as s,f as c,g as l,m as u,p as d,w as f}from"./esm-C2EW83XK.js";import{n as p}from"./emotion-react.browser.esm-C5rzodFX.js";var m=e(t(),1),h=(0,m.memo)(({children:e})=>{let t=(0,m.useContext)(a.reflex___state____state__massloop_fe___state____massloop_state);return p(u,{css:{width:`8px`,height:`8px`,borderRadius:`50%`,backgroundColor:t.backend_ok_rx_state_?`#00ff41`:`#ff0044`,boxShadow:t.backend_ok_rx_state_?`0 0 6px #00ff41`:`0 0 6px #ff0044`}})}),g=(0,m.memo)(({children:e})=>(0,m.useContext)(a.reflex___state____state__massloop_fe___state____massloop_state).backend_status_rx_state_),_=(0,m.memo)(({children:e})=>{let t=(0,m.useContext)(a.reflex___state____state__massloop_fe___state____massloop_state);return`items: `+JSON.stringify(t.queue_length_rx_state_)}),v=(0,m.memo)(({children:e})=>(0,m.useContext)(a.reflex___state____state__massloop_fe___state____massloop_state).queue_length_rx_state_>=0?e?.at?.(0):e?.at?.(1)),y=(0,m.memo)(({children:e})=>p(c,{css:{border:`1px solid #00ff4144`,color:`#00ff41`,backgroundColor:`transparent`,"&:hover":{borderColor:`#00ff41`,color:`#0a0a0a`,backgroundColor:`#00ff41`}},onClick:(0,m.useCallback)((e=>f([i(`reflex___state____state.massloop_fe___state____massloop_state.check_health`,{},{})],[e],{})),[f,i]),variant:`outline`},e)),b=(0,m.memo)(({children:e})=>p(c,{css:{border:`1px solid #ffb00044`,color:`#ffb000`,backgroundColor:`transparent`,"&:hover":{borderColor:`#ffb000`,color:`#0a0a0a`,backgroundColor:`#ffb000`}},onClick:(0,m.useCallback)((e=>f([i(`reflex___state____state.massloop_fe___state____massloop_state.poll_queue`,{},{})],[e],{})),[f,i]),variant:`outline`},e)),x=n(function(){return p(m.Fragment,{},p(m.Fragment,{},p(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`<style>
        body::after {
            content: '';
            position: fixed;
            top: 0; left: 0; width: 100vw; height: 100vh;
            pointer-events: none;
            z-index: 9999;
            background: repeating-linear-gradient(
                0deg,
                transparent,
                transparent 2px,
                rgba(0, 255, 65, 0.03) 2px,
                rgba(0, 255, 65, 0.03) 4px
            );
        }
        @keyframes glitch {
            0% { transform: translate(0); }
            20% { transform: translate(-2px, 1px); }
            40% { transform: translate(2px, -1px); }
            60% { transform: translate(-1px, 2px); }
            80% { transform: translate(1px, -2px); }
            100% { transform: translate(0); }
        }
        .glitch-hover:hover {
            animation: glitch 0.3s ease-in-out;
        }
        @keyframes pulse-glow {
            0%, 100% { filter: drop-shadow(0 0 4px rgba(0, 255, 65, 0.4)); }
            50% { filter: drop-shadow(0 0 12px rgba(0, 255, 65, 0.8)); }
        }
        .pulse-glow {
            animation: pulse-glow 2s ease-in-out infinite;
        }
        </style>`}}),p(d,{align:`start`,className:`rx-Stack`,css:{minHeight:`100vh`,backgroundColor:`#0a0a0a`,alignItems:`center`},direction:`column`,gap:`3`},p(d,{align:`start`,className:`rx-Stack`,css:{padding:`1rem 2rem`,borderBottom:`1px solid #00ff4122`,backgroundColor:`#0a0a0a`},direction:`row`,gap:`3`},p(d,{align:`start`,className:`rx-Stack`,direction:`row`,gap:`2`},p(l,{as:`p`,css:{fontWeight:`700`,color:`#00ff41`,fontSize:`5`}},`massloop`),p(l,{as:`p`,css:{color:`#ff00ff`}},`·`),p(l,{as:`p`,css:{color:`#6b7d8d`,fontSize:`3`}},`stage`)),p(d,{css:{flex:1,justifySelf:`stretch`,alignSelf:`stretch`}}),p(s,{asChild:!0,css:{color:`#6b7d8d`,"&:hover":{color:`#00ff41`},fontSize:`2`}},p(r,{to:`/`},`stage`)),p(l,{as:`p`,css:{color:`#2a2a2a`}},`|`),p(s,{asChild:!0,css:{color:`#6b7d8d`,"&:hover":{color:`#00ff41`},fontSize:`2`}},p(r,{to:`/stage`},`live`)),p(l,{as:`p`,css:{color:`#2a2a2a`}},`|`),p(s,{asChild:!0,css:{color:`#6b7d8d`,"&:hover":{color:`#00ff41`},fontSize:`2`}},p(r,{to:`/health`},`health`))),p(d,{align:`start`,className:`rx-Stack`,css:{padding:`2rem 0`,alignItems:`center`},direction:`column`,gap:`1`},p(l,{as:`p`,css:{fontSize:`6`,fontWeight:`700`,color:`#00ff41`}},`> system/health`),p(l,{as:`p`,css:{color:`#6b7d8d`,fontSize:`2`}},`status check for massloop backend & orchestrator`)),p(u,{css:{border:`1px solid #00ff4133`,borderRadius:`4px`,padding:`1rem`,backgroundColor:`#0a0a0a99`,fontFamily:`monospace`,"--default-font-family":`monospace`,width:`90%`,maxWidth:`520px`}},p(d,{align:`start`,className:`rx-Stack`,css:{alignItems:`start`},direction:`column`,gap:`2`},p(d,{align:`start`,className:`rx-Stack`,direction:`row`,gap:`2`},p(l,{as:`p`,css:{fontSize:`3`,color:`#e0e0e0`,fontWeight:`600`}},`$ backend`),p(h,{})),p(l,{as:`p`,css:{fontSize:`2`,color:`#6b7d8d`,paddingLeft:`1.5rem`}},p(g,{})),p(d,{align:`start`,className:`rx-Stack`,css:{marginTop:`1rem`},direction:`row`,gap:`2`},p(l,{as:`p`,css:{fontSize:`3`,color:`#e0e0e0`,fontWeight:`600`}},`$ queue`),p(u,{css:{width:`8px`,height:`8px`,borderRadius:`50%`,backgroundColor:`#00ff41`,boxShadow:`0 0 6px #00ff41`}})),p(m.Fragment,{},p(v,{},p(m.Fragment,{},p(l,{as:`p`,css:{fontSize:`2`,color:`#6b7d8d`,paddingLeft:`1.5rem`}},p(_,{}))),p(m.Fragment,{},p(l,{as:`p`,css:{fontSize:`2`,color:`#ff0044`,paddingLeft:`1.5rem`}},`queue: unreachable`)))),p(d,{align:`start`,className:`rx-Stack`,css:{marginTop:`1rem`},direction:`row`,gap:`2`},p(l,{as:`p`,css:{fontSize:`3`,color:`#e0e0e0`,fontWeight:`600`}},`$ orchestrator`),p(u,{css:{width:`8px`,height:`8px`,borderRadius:`50%`,backgroundColor:`#00ff41`,boxShadow:`0 0 6px #00ff41`}})),p(l,{as:`p`,css:{fontSize:`2`,color:`#6b7d8d`,paddingLeft:`1.5rem`}},`gpt-4o-mini · cometsuno adapter · chirp-v4`),p(o,{css:{borderColor:`#00ff4122`,margin:`1rem 0`},size:`4`}),p(d,{align:`start`,className:`rx-Stack`,direction:`row`,gap:`4`},p(y,{},`> refresh health`),p(b,{},`> poll queue`)))),p(d,{css:{flex:1,justifySelf:`stretch`,alignSelf:`stretch`}}),p(d,{align:`start`,className:`rx-Stack`,css:{padding:`2rem 0`},direction:`row`,justify:`center`,gap:`3`},p(l,{as:`p`,css:{color:`#2a2a2a`,fontSize:`1`}},`press f5 to re-connect`)))),p(`title`,{},`Massloop · health`),p(`meta`,{content:`favicon.ico`,property:`og:image`}))});export{x as default};