import{r as e}from"./rolldown-runtime-QTnfLwEv.js";import{N as t,j as n,r}from"./chunk-5KNZJZUH-03iYwFZK.js";import{D as i,d as a,f as o,g as s,m as c,p as l,w as u}from"./esm-C2EW83XK.js";import{n as d}from"./emotion-react.browser.esm-C5rzodFX.js";var f=e(t(),1),p=(0,f.memo)(({children:e})=>((0,f.useEffect)(()=>(((...e)=>u([i(`reflex___state____state.massloop_fe___state____massloop_state.check_first_visit`,{},{})],e,{}))(),()=>{}),[]),d(c,{}))),m=(0,f.memo)(({children:e})=>d(o,{className:`glitch-hover`,css:{backgroundColor:`#00ff41`,color:`#0a0a0a`,fontWeight:`700`,fontSize:`4`,padding:`1rem 3rem`,border:`none`,borderRadius:`0`,"&:hover":{backgroundColor:`#ff00ff`,boxShadow:`0 0 20px #00ff4166`}},onClick:(0,f.useCallback)((e=>u([i(`_redirect`,{path:`/onboard`,external:!1,popup:!1,replace:!1},{})],[e],{})),[u,i])},e)),h=n(function(){return d(f.Fragment,{},d(f.Fragment,{},d(p,{}),d(f.Fragment,{},d(`div`,{className:`rx-Html`,dangerouslySetInnerHTML:{__html:`<style>
        body::after {
            content: '';
            position: fixed;
            top: 0; left: 0; width: 100vw; height: 100vh;
            pointer-events: none;
            z-index: 9999;
            background: repeating-linear-gradient(
                0deg,
                transparent,
                transparent 2px,
                rgba(0, 255, 65, 0.03) 2px,
                rgba(0, 255, 65, 0.03) 4px
            );
        }
        @keyframes glitch {
            0% { transform: translate(0); }
            20% { transform: translate(-2px, 1px); }
            40% { transform: translate(2px, -1px); }
            60% { transform: translate(-1px, 2px); }
            80% { transform: translate(1px, -2px); }
            100% { transform: translate(0); }
        }
        .glitch-hover:hover {
            animation: glitch 0.3s ease-in-out;
        }
        @keyframes pulse-glow {
            0%, 100% { filter: drop-shadow(0 0 4px rgba(0, 255, 65, 0.4)); }
            50% { filter: drop-shadow(0 0 12px rgba(0, 255, 65, 0.8)); }
        }
        .pulse-glow {
            animation: pulse-glow 2s ease-in-out infinite;
        }
        </style>`}}),d(l,{align:`start`,className:`rx-Stack`,css:{minHeight:`100vh`,backgroundColor:`#0a0a0a`,alignItems:`center`},direction:`column`,gap:`0`},d(l,{align:`start`,className:`rx-Stack`,css:{padding:`1rem 2rem`,borderBottom:`1px solid #00ff4122`,backgroundColor:`#0a0a0a`,width:`100%`},direction:`row`,gap:`3`},d(s,{as:`p`,css:{fontWeight:`700`,color:`#00ff41`,fontSize:`5`}},`massloop`),d(l,{css:{flex:1,justifySelf:`stretch`,alignSelf:`stretch`}}),d(a,{asChild:!0,css:{color:`#6b7d8d`,"&:hover":{color:`#00ff41`},fontSize:`2`}},d(r,{to:`/stage`},`studio`))),d(l,{align:`start`,className:`rx-Stack`,css:{alignItems:`center`,padding:`4rem 0`},direction:`column`,gap:`6`},d(s,{as:`p`,className:`pulse-glow`,css:{fontSize:`9`,fontWeight:`900`,color:`#00ff41`}},`MASSLOOP`),d(s,{as:`p`,css:{color:`#e0e0e0`,fontSize:`4`,fontWeight:`600`,textAlign:`center`,marginTop:`1rem`}},`AI handles grunt work, you handle the soul`),d(c,{css:{border:`1px solid #00ff4133`,borderRadius:`4px`,padding:`1rem`,backgroundColor:`#0a0a0a99`,fontFamily:`monospace`,"--default-font-family":`monospace`,width:`90%`,maxWidth:`600px`,marginTop:`2rem`,marginBottom:`2rem`}},d(l,{align:`start`,className:`rx-Stack`,css:{alignItems:`center`},direction:`column`,gap:`4`},d(s,{as:`p`,css:{color:`#6b7d8d`,fontSize:`2`,textAlign:`center`,lineHeight:`1.5`}},`Massloop is a stage-confidence amplifier. It leverages a Multi-Agent Orchestrator (MOA) to generate underground electronic music in real-time, allowing you to focus on the performance while the AI manages the technical grunt work of track structure, energy flow, and sonic cohesion.`))),d(m,{},`▶ ENTER THE STUDIO`),d(s,{as:`p`,css:{color:`#ffb000`,fontSize:`1`,marginTop:`1rem`}},`demo: $0.50/track · no subscription`)),d(l,{align:`start`,className:`rx-Stack`,css:{padding:`2rem 0`},direction:`row`,justify:`center`,gap:`3`},d(s,{as:`p`,css:{color:`#2a2a2a`,fontSize:`1`}},`v0.1.0 · `),d(a,{asChild:!0,css:{color:`#00ff41`,fontSize:`1`,"&:hover":{color:`var(--accent-8)`}}},d(r,{to:`https://massloop.run`},`massloop.run`)),d(s,{as:`p`,css:{color:`#2a2a2a`,fontSize:`1`}},` · built with fastapi + reflex + suno`))))),d(`title`,{},`Massloop · landing`),d(`meta`,{content:`favicon.ico`,property:`og:image`}))});export{h as default};